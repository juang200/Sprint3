package Userinterfaces.HU0001;


import net.serenitybdd.screenplay.targets.Target;

public class Botones {

    public static final Target BUTTON_USUARIO = Target.the("Campos para ingresar usuario").locatedBy("//input[contains(@id,'mui-1')]");

    public static final Target BUTTON_CONTRASENA = Target.the("Campos para ingresar contraseña").locatedBy("//input[contains(@id,'mui-2')]");

    public static final Target BUTTON_INGRESAR = Target.the("Campos para ingresar contraseña").locatedBy("//p[contains(.,'Ingresar')]");

}
