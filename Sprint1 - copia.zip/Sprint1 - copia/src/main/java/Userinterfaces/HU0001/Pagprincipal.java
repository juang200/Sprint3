package Userinterfaces.HU0001;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class Pagprincipal {

    public static final Target TEXT_VALID = Target.the("Se verifica la pagina principal").locatedBy("//p[@class='MuiTypography-root MuiTypography-body1 MuiTypography-alignRight color-text css-nozzr0-MuiTypography-root'][contains(.,'Hola AsminOperador')]");
    public static final Target WARNING_TEXT = Target.the("Se verifica mensaje de advertencia").locatedBy("//span[@data-notify='message'][contains(.,'Por favor validar la información. Nombre de usuario o contraseña incorrectos')]");


}
