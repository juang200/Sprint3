package Userinterfaces.HU0003;


import net.serenitybdd.screenplay.targets.Target;

public class Botones {

    public static final Target MENU_PRINCIPAL = Target.the("Seleccionar menu principal").locatedBy("@FindBy(xpath = \"//img[@src='/static/media/logo-neat-mini-hover.92d4502d.svg']\")]");
    public static final Target ICONO_CONFIGURACION = Target.the("Seleccionar configuracion").locatedBy("//p[@class='sidebar-text'][contains(.,'Configuración')]");

    public static final Target ICONO_MENU = Target.the("Seleccionar modulo gestion de menus").locatedBy("(//span[contains(.,'Gestión Menus')])[2]");

    public static final Target ICONO_CREAR_MENU = Target.the("Seleccionar icono crear menu").locatedBy("//i[contains(@class,'fa-solid fa-plus')]");

}