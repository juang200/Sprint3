package Variables;

public class variablesMenu {

    private String nombre;
    private String url;
    private String icono;
    private String orden;
    private String estado;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


}
