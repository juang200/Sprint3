package question;

import Userinterfaces.HU0001.Pagprincipal;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static Userinterfaces.HU0001.Pagprincipal.TEXT_VALID;

public class loginQuestion implements Question {

    private final String validtext;

    public loginQuestion(String validtext) {
        this.validtext = validtext;
    }

    @Override
    public Object answeredBy(Actor actor) {
        if (Text.of(Pagprincipal.TEXT_VALID).viewedBy(actor).asString().contains(validtext.toString()))
            return true;
            else
            return false;
    }

    public static loginQuestion loginvalidtext (String validtext){
        return new loginQuestion(validtext);
    }
}
