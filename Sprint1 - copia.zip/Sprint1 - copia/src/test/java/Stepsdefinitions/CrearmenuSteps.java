package Stepsdefinitions;

import cucumber.api.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

import static Userinterfaces.HU0003.Botones.*;

public class CrearmenuSteps {

    @Managed (driver = "Chrome")
    private WebDriver navegador;
    private Actor actor = Actor.named("Juan");


    @Given("^The user open the create menu page$")
    public void the_user_open_the_create_menu_page() {
        actor.attemptsTo(
                Click.on(MENU_PRINCIPAL), //

                Click.on(ICONO_CONFIGURACION)




        );
    }

    @When("^He complete the register and save the new menu$")
    public void he_complete_the_register_and_save_the_new_menu() {


    }

    @Then("^He see the succesful message$")
    public void he_see_the_succesful_message() {

    }

    }

