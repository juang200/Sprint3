package Stepsdefinitions;

import Tasks.Insertardatos;
import Userinterfaces.HU0001.Homepage;
import cucumber.api.java.en.*;

import net.serenitybdd.core.webdriver.enhancers.AtTheEndOfAWebDriverTest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.questions.SelectedStatus;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import question.loginQuestion;
import question.loginQuestion2;

import java.beans.Visibility;

import static Userinterfaces.HU0001.Botones.BUTTON_INGRESAR;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isPresent;
import static net.serenitybdd.screenplay.targets.Target.the;

public class LoginSteps {

    @Managed(driver = "chrome")
    private WebDriver navegador;
    private Homepage homepage = new Homepage();
    private Actor actor = Actor.named("Juan");

    @Given("^The user enters to Neat administration page$")
    public void the_user_enters_to_Neat_administration_page() {
        actor.can(BrowseTheWeb.with(navegador));
        actor.wasAbleTo(Open.browserOn(homepage));

    }

    @When("^He puts the (.*) and the (.*)$")
    public void he_puts_the_user_and_the_password(String usuario, String contrasena) {
        actor.wasAbleTo(
                Insertardatos.conDatos(usuario, contrasena)
        );
    }
    @Then("^He see the administrative page (.*)$")
    public void he_see_the_administrative_page(String validtext) {
        theActorInTheSpotlight().should(GivenWhenThen.seeThat(loginQuestion.loginvalidtext(validtext)));
    }

// Pasos para realizar el login con datos incorrectos, no existentes en la base de datos

    @When("^He puts in the user (.*) and password (.*)$")
    public void hePutsInTheUserJuanAndPassword(String usuario, String contrasena) {
        actor.wasAbleTo(
                Insertardatos.conDatos(usuario, contrasena)
        );
    }


    @Then("^He see the warnning message (.*)$")
    public void heSeeTheWarnningMessage(String advertencia) {
        theActorInTheSpotlight().should(GivenWhenThen.seeThat(loginQuestion2.loginadvertencia(advertencia)));

        }


// Pasos realizar login sin ingresar datos

    @Then("^He see the administrative message$")
    public void heSeeTheAdministrativeMessage() {
        actor.attemptsTo(
                Click.on(BUTTON_INGRESAR)
        );
    }








}

