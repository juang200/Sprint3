package Userinterfaces.HU0008;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://localhost:3000/")

public class Homepage extends PageObject {


}
